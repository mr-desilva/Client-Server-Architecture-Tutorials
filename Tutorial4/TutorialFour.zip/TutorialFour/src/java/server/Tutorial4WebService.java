/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author andre
 */
@WebService(serviceName = "Tutorial4WebService")
public class Tutorial4WebService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "isConnected")
    public Boolean isConnected() {
        System.out.println("[SERVER] - Testing Connection...");
        return true;
    }

    /**
     * Web service operation
     * @throws java.lang.Exception
     */
    @WebMethod(operationName = "addWithExceptions")
    public Double addWithExceptions(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) throws Exception {
        //TODO write your implementation code here:
       if(b == null)
            throw new Exception( "[SERVER] - Variable 2 Cannot be null");
        
        if(a == null)
            throw new Exception( "[SERVER] - Variables 1 variables cannot be null");
        
        if((a == null) && (b == null)) {
            throw new Exception( "[SERVER] - Both variables cannot be null");
        }
        return a + b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "divideWithException")
    public Double divideWithException(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) throws Exception {
        //TODO write your implementation code here:
        if(b == 0)
            throw new Exception( "[SERVER] - Variable 2 Cannot be zero");
        if ((b == 0) && (a == 0))
            throw new Exception( "[SERVER] - Both variables cannot be zero");
        if  ((a == null) && (b == null))
            throw new Exception( "[SERVER] - Both variables cannot be null");
        if(b == null)
            throw new Exception( "[SERVER] - Variable 2 Cannot be null");
        if(a == null)
            throw new Exception( "[SERVER] - Variable 1 Cannot be null");
        return a/b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "substractWithException")
    public Double substractWithException(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) throws Exception {
        //TODO write your implementation code here:
        if(b == null)
            throw new Exception( "[SERVER] - Variable 2 Cannot be null");
        
        if(a == null)
            throw new Exception( "[SERVER] - Variables 1 variables cannot be null");
        
        if((a == null) && (b == null)) {
            throw new Exception( "[SERVER] - Both variables cannot be null");
        }
        return a-b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "multiplyWithException")
    public Double multiplyWithException(@WebParam(name = "a") Double a, @WebParam(name = "b") Double b) throws Exception {
        //TODO write your implementation code here:
        if(b == null)
            throw new Exception( "[SERVER] - Variable 2 Cannot be null");
        
        if(a == null)
            throw new Exception( "[SERVER] - Variables 1 variables cannot be null");
        
        if((a == null) && (b == null)) {
            throw new Exception( "[SERVER] - Both variables cannot be null");
        }
        return a*b;
    }

}
